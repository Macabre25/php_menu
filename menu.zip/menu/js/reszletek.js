function reszletek(cid, cszam, cnev, car, cinfo, ckep, sKeszleten) {
    $('#cikkModal h4').html(cnev);
    $('#cikkModal .modal-body .kep').html('<img src="' + ckep + '" width="100%">');
    $('#cikkModal .modal-body .leiras').html('<p><b>Cikkszám: </b>' + cszam + '</p><p><b>Leírás: </b>' + cinfo + '</p>');
    $('#cikkModal .modal-body .ar h2').html(car.toLocaleString() + ' Ft');
    $('#gombKosarba').attr("onclick", "kosarba(" + cid + ", 0" + ")");
    $('#sKeszleten').html(sKeszleten);
}
