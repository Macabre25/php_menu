   <div class="container">
        <div class="row">
        <?php require_once 'header.php'; ?>
        <?php require_once 'side.php';   ?> 
        <?php require_once 'main.php';   ?>
        <?php require_once 'footer.php'; ?>
        </div> 
    </div>
