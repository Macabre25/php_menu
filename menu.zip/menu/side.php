<div class="col-md-2 ">
           <ul>
<?php

 echo '<p><a href="index.php " class="btn btn-danger " > Aktualitások </a></p>';
    echo '<p><a href="Rolunk.php" class="btn btn-danger " > Rólunk </a></p>';
    echo '<p><a href="Szolgaltatas.php" class="btn btn-danger" > Szolgáltatás </a></p>';
    echo '<p><a href="Referenciak.php" class="btn btn-danger" > Referenciák </a></p>';
    echo '<p><a href="Elerhetoseg.php" class="btn btn-danger" > Elérhetőség </a></p>';
    echo '<p><a href="Kapcsolat.php" class="btn btn-danger" > Kapcsolat </a></p>';
    echo '<p><a href="Karrier.php" class="btn btn-danger" > Karrier </a></p>';

  
    ?>
           </ul>
       </div>