<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Menü</title>
          <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <script src='https://www.google.com/recaptcha/api.js'></script>
        <script src="js/jquery-3.5.1.min.js" type="text/javascript"></script>

    </head>
    <body>
<?php echo '<h1 class="text-center">PHP menü mintapélda</h1>'; ?>
